// lib/utils/format.ts - rebuilt content
