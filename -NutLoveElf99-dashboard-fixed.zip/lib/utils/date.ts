// lib/utils/date.ts - rebuilt content
