// app/admin/bills/page.tsx - rebuilt content
