// app/admin/dashboard/page.tsx - rebuilt content
