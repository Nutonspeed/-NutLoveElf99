// core/mock/customer/index.ts - rebuilt content
