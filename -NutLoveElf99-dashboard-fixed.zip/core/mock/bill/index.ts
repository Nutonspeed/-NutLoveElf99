// core/mock/bill/index.ts - rebuilt content
