// components/admin/DashboardStats.tsx - rebuilt content
