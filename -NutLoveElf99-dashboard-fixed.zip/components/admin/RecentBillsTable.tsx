// components/admin/RecentBillsTable.tsx - rebuilt content
